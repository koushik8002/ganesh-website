// When the page loads, show a welcome popup
window.onload = function() {
    alert("🙏 Welcome to the Ganesh Chaturthi Special Website by Koushik, Siva Kalki & Hema Sagar!");
};